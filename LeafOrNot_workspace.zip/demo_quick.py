
import json, sys, os
import cv2
from leafdet.quick_rule import quick_leaf_rule

def run(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(image_path)
    label, score, diag = quick_leaf_rule(img)
    return {"input": os.path.basename(image_path), "label": label, "score": score, "diagnostics": diag}

if __name__ == "__main__":
    img_path = sys.argv[1]
    print(json.dumps(run(img_path), indent=2))
